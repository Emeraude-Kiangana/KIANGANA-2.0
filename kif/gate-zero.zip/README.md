# KIANGANA INTELLIGENCE FABRIC — Gate Zero

Provider-agnostic personal AI orchestration infrastructure. This repository currently implements **Gate Zero only**.

## What Gate Zero proves

`TaskEnvelope → Router → DeepSeekAdapter → real DeepSeek API → ResponseEnvelope → UsageRecord → pytest PASS`

No routing logic, no scoring, no fallback, no AWS, no tools, no memory.

## Requirements
- Python >= 3.12
- A DeepSeek API key (`DEEPSEEK_API_KEY`)

## Installation
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

## Environment
```bash
cp .env.example .env
# edit .env
```

Current documented model default: `deepseek-flash`.

## Unit tests
```bash
pytest tests/unit -q
```

## Integration test
```bash
pytest tests/integration -q -s
```
If the key is absent, the test is SKIPPED, never PASS.

## CLI
```bash
kif ask "Reply with exactly one word: pong"
```

## Known limitations
- Single provider (DeepSeek only).
- No scoring, no fallback, no retry.
- `estimated_cost` and `actual_cost` are null in Gate Zero.
- Usage uses local JSONL.
- No tools, memory, automations, or serverless deployment.
